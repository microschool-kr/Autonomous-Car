# 2023-Winter-Camp
2023 Winter Camp using arduino and python
